<!-- <div class="my-form">
    <form action="<?php echo home_url('2023/07/03/home/') ?>" id="my-search-from">
        <input type="hidden" name="page" value="home">
        <input type="text" name="my_search_term" id="my-search-term">
        <input type="submit" value="Search" name="search">
        <ul id="posts">
            <li style="list-style: none;"></li>
        </ul>
    </form>
</div> -->
<div class="my-form">
    <input type="text" name="s" class="keyword" autocomplete="off" >
    <div class="loaddata">
       
    </div>
</div>